'use client'

import React, { useEffect, useMemo, useRef, useState } from 'react'
import useEmblaCarousel from 'embla-carousel-react'
import AutoplayImport from 'embla-carousel-autoplay'

const Autoplay = (AutoplayImport as any)?.default ?? AutoplayImport

type GalleryItem = {
  uid: string
  url: string
  caption?: string
  enabled?: boolean
}

type GallerySettings = {
  heading?: string
  items: GalleryItem[]
  layout?: {
    containerMode?: 'full' | 'moldura' | 'autoadapter'
    gapPx?: number
    sidePaddingPx?: number
    itemWidthPx?: number
    itemHeightPx?: number
    objectFit?: 'cover' | 'contain'
    autoplay?: boolean
    autoplayIntervalMs?: number
    showDots?: boolean
    showArrows?: boolean
    arrowsDesktopOnly?: boolean
  }
}

type GalleryStyle = {
  headingFontFamily?: string
  headingFontWeight?: number
  headingColor?: string
  headingBold?: boolean
  headingAlign?: 'left' | 'center' | 'right'
  headingFontSize?: number

  container?: {
    bgColor?: string
    radius?: number
    padding?: number
    shadow?: boolean
    borderWidth?: number
    borderColor?: string
    enabled?: boolean
  }

  carouselArrowsBg?: string
  carouselArrowsIconColor?: string
  carouselDotsColor?: string
  carouselDotsActiveColor?: string
}

type Props = {
  settings: GallerySettings
  style?: GalleryStyle
}

function isNonEmpty(v?: string) {
  return typeof v === 'string' && v.trim().length > 0
}

function containerStyleFromJson(style: GalleryStyle['container']): React.CSSProperties {
  const s = style || {}
  const enabled = s.enabled !== false

  return {
    backgroundColor: enabled ? (s.bgColor ?? 'transparent') : 'transparent',
    borderRadius: s.radius != null ? `${s.radius}px` : undefined,
    padding: s.padding != null ? `${s.padding}px` : '16px',
    boxShadow: s.shadow ? '0 10px 30px rgba(0,0,0,0.14)' : undefined,
    borderStyle: s.borderWidth ? 'solid' : undefined,
    borderWidth: s.borderWidth ? `${s.borderWidth}px` : undefined,
    borderColor: s.borderColor ?? undefined,
  }
}

export default function GalleryBlock({ settings, style }: Props) {
  const s = settings || ({ items: [] } as any)
  const st = style || {}

  const containerStyle = containerStyleFromJson(st.container)
  const containerMode = s.layout?.containerMode ?? 'full'

  const gapPx = s.layout?.gapPx ?? 16

  const sidePaddingPx =
    typeof s.layout?.sidePaddingPx === 'number'
      ? s.layout.sidePaddingPx
      : containerMode === 'full'
        ? 0
        : 16

  const itemWidthPx = s.layout?.itemWidthPx ?? (containerMode === 'autoadapter' ? 180 : 240)
  const itemHeightPx = s.layout?.itemHeightPx ?? (containerMode === 'autoadapter' ? 120 : 160)
  const objectFit = s.layout?.objectFit ?? 'cover'

  const autoplayEnabled = s.layout?.autoplay !== false
  const autoplayIntervalMs = s.layout?.autoplayIntervalMs ?? 3500

  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null)

  const visibleItems = useMemo(() => {
    const arr = Array.isArray(s.items) ? s.items : []
    return arr.filter((item) => item && item.enabled !== false && item.url)
  }, [s.items])

  const loop = visibleItems.length > 1

  // ✅ Autoplay (safe)
  const autoplay = useRef<any>(null)
  if (!autoplay.current && typeof Autoplay === 'function') {
    autoplay.current = Autoplay({ delay: autoplayIntervalMs, stopOnInteraction: true, stopOnMouseEnter: true })
  }
  const plugins = autoplayEnabled && loop && autoplay.current ? [autoplay.current] : []

  // ✅ IMPORTANTÍSSIMO: hook é sempre chamado (nunca pode ficar depois de um return condicional)
  const [emblaRef, emblaApi] = useEmblaCarousel(
    {
      loop,
      align: 'center',
      dragFree: false,
      containScroll: 'trimSnaps',
    },
    plugins
  )

  // ===== UI do Carrossel (setas + dots) =====
  const showDots = s.layout?.showDots !== false
  const showArrows = s.layout?.showArrows !== false
  const arrowsDesktopOnly = s.layout?.arrowsDesktopOnly !== false

  const [selectedIndex, setSelectedIndex] = useState(0)
  const [snapCount, setSnapCount] = useState(0)
  const [isDesktop, setIsDesktop] = useState(false)

  useEffect(() => {
    const mq = window.matchMedia('(min-width: 768px)')
    const update = () => setIsDesktop(mq.matches)
    update()
    mq.addEventListener?.('change', update)
    return () => mq.removeEventListener?.('change', update)
  }, [])

  useEffect(() => {
    if (!emblaApi) return

    const onSelect = () => setSelectedIndex(emblaApi.selectedScrollSnap() || 0)
    const onReInit = () => {
      setSnapCount(emblaApi.scrollSnapList().length)
      onSelect()
    }

    setSnapCount(emblaApi.scrollSnapList().length)
    onSelect()

    emblaApi.on('select', onSelect)
    emblaApi.on('reInit', onReInit)

    return () => {
      emblaApi.off('select', onSelect)
      emblaApi.off('reInit', onReInit)
    }
  }, [emblaApi])

  const arrowsBg = st.carouselArrowsBg ?? 'rgba(255,255,255,0.9)'
  const arrowsIcon = st.carouselArrowsIconColor ?? '#111827'
  const dotsColor = st.carouselDotsColor ?? 'rgba(0,0,0,0.25)'
  const dotsActiveColor = st.carouselDotsActiveColor ?? 'rgba(0,0,0,0.65)'

  const canUseCarouselUi = visibleItems.length > 1
  const showArrowsNow = canUseCarouselUi && showArrows && (!arrowsDesktopOnly || isDesktop)
  const prev = () => emblaApi?.scrollPrev()
  const next = () => emblaApi?.scrollNext()
  const goTo = (idx: number) => emblaApi?.scrollTo(idx)

  // ✅ agora sim: se não há items, não renderiza (mas hooks já foram chamados)
  if (visibleItems.length === 0) return null

  const viewportStyle: React.CSSProperties = {
    ...containerStyle,
    overflow: 'hidden',
    padding: containerMode === 'full' ? 0 : containerStyle.padding,
    borderRadius: containerMode === 'full' ? 0 : containerStyle.borderRadius,
    boxShadow: containerMode === 'full' ? 'none' : containerStyle.boxShadow,
    borderStyle: containerMode === 'full' ? 'none' : containerStyle.borderStyle,
    borderWidth: containerMode === 'full' ? 0 : containerStyle.borderWidth,
    borderColor: containerMode === 'full' ? 'transparent' : containerStyle.borderColor,
  }

  return (
    <section>
      {isNonEmpty(s.heading) && (
        <div
          style={{
            fontWeight: st.headingBold === false ? 500 : (st.headingFontWeight ?? 900),
            fontSize: st.headingFontSize ?? 13,
            opacity: 0.75,
            marginBottom: 10,
            fontFamily: st.headingFontFamily || undefined,
            color: st.headingColor ?? '#111827',
            textAlign: st.headingAlign ?? 'left',
          }}
        >
          {s.heading}
        </div>
      )}

      <div style={{ position: 'relative' }}>
        <div style={viewportStyle} ref={emblaRef}>
        <div
          style={{
            display: 'flex',
            gap: gapPx,
            paddingLeft: sidePaddingPx,
            paddingRight: sidePaddingPx,
            paddingBottom: 2,
            touchAction: 'pan-y',
            WebkitTapHighlightColor: 'transparent',
          }}
        >
          {visibleItems.map((item, i) => (
            <div key={item.uid} style={{ flex: '0 0 auto', width: itemWidthPx }}>
              <div
                style={{
                  cursor: 'pointer',
                  borderRadius: 12,
                  overflow: 'hidden',
                  position: 'relative',
                  boxShadow: '0 2px 8px rgba(0,0,0,0.12)',
                  width: itemWidthPx,
                  height: itemHeightPx,
                }}
                onClick={() => setLightboxIndex(i)}
              >
                <img
                  src={item.url}
                  alt={item.caption || `Imagem ${i + 1}`}
                  style={{ width: '100%', height: '100%', objectFit, display: 'block' }}
                  loading="lazy"
                  draggable={false}
                />

                {isNonEmpty(item.caption) && (
                  <div
                    style={{
                      position: 'absolute',
                      bottom: 0,
                      width: '100%',
                      background: 'rgba(0,0,0,0.4)',
                      color: 'white',
                      padding: '4px 8px',
                      fontSize: 12,
                      textAlign: 'center',
                      userSelect: 'none',
                    }}
                  >
                    {item.caption}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
        </div>

        {showArrowsNow && (
          <>
            <button type="button" onClick={prev} aria-label="Anterior" style={arrowStyle('left', arrowsBg, arrowsIcon)} data-no-block-select="1">
              ‹
            </button>
            <button type="button" onClick={next} aria-label="Seguinte" style={arrowStyle('right', arrowsBg, arrowsIcon)} data-no-block-select="1">
              ›
            </button>
          </>
        )}

        {canUseCarouselUi && showDots && snapCount > 1 && (
          <div style={{ display: 'flex', justifyContent: 'center', gap: 8, marginTop: 10, userSelect: 'none' }} data-no-block-select="1">
            {Array.from({ length: snapCount }).map((_, i) => {
              const active = i === selectedIndex
              return (
                <button
                  key={i}
                  type="button"
                  onClick={() => goTo(i)}
                  aria-label={`Ir para a imagem ${i + 1}`}
                  style={{
                    width: 8,
                    height: 8,
                    borderRadius: 999,
                    border: 'none',
                    padding: 0,
                    cursor: 'pointer',
                    backgroundColor: active ? dotsActiveColor : dotsColor,
                    transform: active ? 'scale(1.15)' : 'scale(1)',
                    transition: 'transform 120ms ease, background-color 120ms ease',
                  }}
                />
              )
            })}
          </div>
        )}
      </div>

      {lightboxIndex !== null && (
        <Lightbox
          items={visibleItems}
          currentIndex={Math.max(0, Math.min(visibleItems.length - 1, lightboxIndex))}
          onClose={() => setLightboxIndex(null)}
          onNavigate={(newIndex) => setLightboxIndex(newIndex)}
        />
      )}
    </section>
  )
}

function arrowStyle(side: 'left' | 'right', bg: string, icon: string): React.CSSProperties {
  return {
    position: 'absolute',
    top: '50%',
    transform: 'translateY(-50%)',
    [side]: 6,
    width: 34,
    height: 34,
    borderRadius: 999,
    border: '1px solid rgba(0,0,0,0.10)',
    background: bg,
    color: icon,
    display: 'grid',
    placeItems: 'center',
    cursor: 'pointer',
    userSelect: 'none',
    boxShadow: '0 10px 26px rgba(0,0,0,0.10)',
    fontSize: 22,
    lineHeight: 1,
    zIndex: 5,
  }
}

/* ===== Lightbox ===== */

type LightboxProps = {
  items: GalleryItem[]
  currentIndex: number
  onClose: () => void
  onNavigate: (index: number) => void
}

function Lightbox({ items, currentIndex, onClose, onNavigate }: LightboxProps) {
  const safeItems = Array.isArray(items) ? items : []
  const item = safeItems[currentIndex]

  useEffect(() => {
    if (!item) onClose()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentIndex, safeItems.length])

  const prev = () => onNavigate((currentIndex - 1 + safeItems.length) % safeItems.length)
  const next = () => onNavigate((currentIndex + 1) % safeItems.length)

  const [zoom, setZoom] = useState<1 | 2>(1)
  useEffect(() => setZoom(1), [currentIndex])

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose()
      if (e.key === 'ArrowLeft') prev()
      if (e.key === 'ArrowRight') next()
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentIndex, safeItems.length])

  const startXRef = useRef<number | null>(null)
  if (!item) return null

  return (
    <div
      onClick={onClose}
      onTouchStart={(e) => (startXRef.current = e.touches[0]?.clientX ?? null)}
      onTouchEnd={(e) => {
        const startX = startXRef.current
        const endX = e.changedTouches[0]?.clientX ?? null
        if (startX == null || endX == null) return
        const dx = endX - startX
        if (Math.abs(dx) < 40) return
        if (dx > 0) prev()
        else next()
      }}
      style={{
        position: 'fixed',
        inset: 0,
        backgroundColor: 'rgba(0,0,0,0.82)',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        zIndex: 9999,
        cursor: 'zoom-out',
        padding: 16,
      }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          position: 'relative',
          maxWidth: '92vw',
          maxHeight: '92vh',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          cursor: 'default',
        }}
      >
        <div style={{ maxWidth: '92vw', maxHeight: '82vh', overflow: 'auto', borderRadius: 12 }}>
          <img
            src={item.url}
            alt={item.caption || `Imagem ${currentIndex + 1}`}
            style={{
              maxWidth: zoom === 1 ? '92vw' : '160vw',
              maxHeight: zoom === 1 ? '82vh' : '140vh',
              borderRadius: 12,
              display: 'block',
              cursor: zoom === 1 ? 'zoom-in' : 'zoom-out',
            }}
            onClick={() => setZoom((z) => (z === 1 ? 2 : 1))}
            loading="eager"
            draggable={false}
          />
        </div>

        {item.caption && (
          <div style={{ marginTop: 10, color: 'white', fontSize: 14, textAlign: 'center' }}>
            {item.caption}
          </div>
        )}

        <button onClick={prev} style={navBtnLeft} aria-label="Imagem anterior">
          ‹
        </button>

        <button onClick={next} style={navBtnRight} aria-label="Próxima imagem">
          ›
        </button>

        <button onClick={onClose} style={closeBtn} aria-label="Fechar">
          ×
        </button>
      </div>
    </div>
  )
}

const navBtnLeft: React.CSSProperties = {
  position: 'absolute',
  top: '50%',
  left: 8,
  transform: 'translateY(-50%)',
  background: 'rgba(255,255,255,0.22)',
  border: '1px solid rgba(255,255,255,0.18)',
  borderRadius: 999,
  width: 44,
  height: 44,
  cursor: 'pointer',
  fontSize: 26,
  fontWeight: 900,
  color: '#fff',
  userSelect: 'none',
}

const navBtnRight: React.CSSProperties = { ...navBtnLeft, left: 'auto', right: 8 }

const closeBtn: React.CSSProperties = {
  position: 'absolute',
  top: 8,
  right: 8,
  background: 'rgba(255,255,255,0.22)',
  border: '1px solid rgba(255,255,255,0.18)',
  borderRadius: 999,
  width: 36,
  height: 36,
  cursor: 'pointer',
  fontSize: 22,
  fontWeight: 900,
  color: '#fff',
  userSelect: 'none',
  lineHeight: 1,
}
