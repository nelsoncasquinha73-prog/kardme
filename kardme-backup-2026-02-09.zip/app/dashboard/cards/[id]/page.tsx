'use client'

export default function CardDashboardPage() {
  return (
    <div
      style={{
        padding: 40,
        fontSize: 18,
        background: '#f7f7f9',
      }}
    >
      🚧 Editor desligado temporariamente  
      <br />
      Estamos a reconstruir o Header como bloco base.
    </div>
  )
}
