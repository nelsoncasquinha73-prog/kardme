export default function AdminSettingsPage() {
  return <div style={{ padding: 20 }}>⚙️ Configurações (em construção)</div>
}
